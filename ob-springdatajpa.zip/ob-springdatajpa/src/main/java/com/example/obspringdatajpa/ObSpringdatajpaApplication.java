package com.example.obspringdatajpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObSpringdatajpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ObSpringdatajpaApplication.class, args);
	}

}
