package com.example.obspringseguritycifradomaven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObSpringSegurityCifradoMavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(ObSpringSegurityCifradoMavenApplication.class, args);
	}

}
