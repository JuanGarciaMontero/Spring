package com.example.obspringseguritycifradomaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObSpringSegurityCifradoMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
