package com.example.obspringseguritycifrado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObSpringSegurityCifradoApplicationTests {

	@Test
	void contextLoads() {
	}

}
